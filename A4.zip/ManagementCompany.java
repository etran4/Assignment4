package Assignment4;

public class ManagementCompany 
{
	// all private variables
	private final int MAX_PROPERTY = 5;
	private double mgmFeePer;
	private String name;
	private Property[] properties;
	private String taxId;
	private final int MGMT_WIDTH = 10;
	private final int MGMT_DEPTH = 10;
	private Plot plot;
	
	public ManagementCompany()
	{
		name = "";
		taxId = "";
		plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
		properties = new Property[MAX_PROPERTY];
	}
	
	public ManagementCompany(String name, String taxId, double mgmFee) 
	{
		this.name = name;
		this.taxId = taxId;
		this.mgmFeePer = mgmFee;
		plot = new Plot (0, 0, MGMT_WIDTH, MGMT_DEPTH);
		properties = new Property[MAX_PROPERTY];
	}
	
	public ManagementCompany(String name, String taxId, double mgmFee, int x, int y, int width, int depth) 
	{
		this.name = name;
		this.taxId = taxId;
		this.mgmFeePer = mgmFee;
		plot = new Plot(x, y, width, depth);
		properties = new Property[MAX_PROPERTY];
	}
	
	public ManagementCompany(ManagementCompany company) 
	{
		this.name = company.name;
		this.taxId = company.taxId;
		this.mgmFeePer = company.mgmFeePer;
		plot = new Plot(company.plot.getX(), company.plot.getY(), company.plot.getWidth(), company.plot.getDepth());
		properties = new Property[MAX_PROPERTY];
	}
	
	// checks if there is a problem adding a property
	private int verifyProperty(Property property)
	{
		for (int x = 0; x < properties.length; x++) 
		{
			if (properties[x] == null) 
			{
				if (property == null) 
				{
					return -2;
				} 
				else if (!(plot.encompasses(property.getPlot()))) 
				{
					return -3;
				} 
				else 
				{
					for (int y = 0; y < x; y++)
					{
						if (property.getPlot().overlaps(properties[y].getPlot())) 
						{
							return -4;
						}
					}
				}			
				properties[x] = property;
				return x;
			}
		}		
		return -1; 
	}
	
	// creates a property object by copying from another property and adds it to properties array.
	public int addProperty(Property p) 
	{
		Plot pPlot = p.getPlot();
		Property property = new Property(p.getCity(), p.getPropertyName(),  p.getRentAmount(), p.getOwner(), pPlot.getX(), pPlot.getY(), p.getPlot().getWidth(), p.getPlot().getDepth());
		
		return verifyProperty(property);
	}
	
	// creates a property object with the default plot and adds it to properties array.
	public int addProperty(String name, String city, double rent, String owner) 
	{
		Property property = new Property(name, city, rent, owner, 0, 0, MGMT_WIDTH, MGMT_DEPTH);
		return verifyProperty(property);
	}
	//  creates a property object and adds it to properties array.
	public int addProperty(String name, String city, double rent, String owner, int x, int y, int width, int depth) 
	{
		Property property = new Property(name, city, rent, owner, x, y, width, depth);
		return verifyProperty(property);
	}
	
	// displays the information of the property at index x
	public String displayPropertyAtIndex(int index) 
	{
		return properties[index].toString();
	}
	
	// sets the name
	public void setName(String name) 
	{
		this.name = name;
	}
	
	// returns company name
	public String getName() 
	{
		return name;
	}
	
	// return company plot
	public Plot getPlot() 
	{
		return plot;
	}
	
	// return the MAX_PROPERTY constant
	public int getMAX_PROPERTY() 
	{
		return MAX_PROPERTY;
	}
	
	// finds a property within properties array that has the maximum amount of rent and returns the rent amount.
	public double maxRentProp()
	{
		double max = 0;
		
		for (int x = 0; x < properties.length; x++) 
		{
			Property property = properties[x];
			
			if (property != null && property.getRentAmount() > max) 
			{
				max = property.getRentAmount();
			}
		}		
		return max;
	}
	
	// finds the index of the property with the maximum amount of rent.
	public int maxPropertyIndex() 
	{
		double max = 0;
		int maxIndex = 0;
		for (int x = 0; x < properties.length; x++) 
		{
			Property property = properties[x];
			
			if (property != null && property.getRentAmount() > max)
			{
				max = property.getRentAmount();
				maxIndex = x;
			}
		}		
		return maxIndex;
	}
	
	// accesses every Property object within array properties and adds up the property rent and returns the total amount.
	public double totalRent() 
	{
		double total = 0;
		for (int x = 0; x < properties.length; x++) 
		{
			Property property = properties[x];
			
			if (property != null) 
			{
				total += property.getRentAmount();
			}
		}	
		return total;
	}
	
	// displays all information of all the properties in properties array.
	public String toString() 
	{
		String returning = "";
		for (int x = 0; x < properties.length; x++) 
		{
			Property property = properties[x];
			
			if (property != null) 
			{
				returning += property.toString();
			}	
		}
		return returning;
	}	
}
// Ethan Tran