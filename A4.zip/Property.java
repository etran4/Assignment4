package Assignment4;

public class Property 
{
	private String owner;
	private double rentAmount;
	private String city;
	private String propertyName;
	private Plot plot;
	
	public Property() 
	{
		city = "";
		owner = "";
		propertyName = "";
		rentAmount = 0;
		plot = new Plot();
	}
	
	public Property(Property p) 
	{
		this.city = p.city;
		this.owner = p.owner;
		this.propertyName = p.propertyName;
		this.rentAmount = p.rentAmount;
		this.plot = new Plot(p.plot.getX(), p.plot.getY(), p.plot.getWidth(), p.plot.getDepth());
	}
	
	public Property(String name, String city, double rentAmount, String owner) 
	{
		this.propertyName = name;
		this.city = city;
		this.owner = owner;
		this.rentAmount = rentAmount;
		this.plot = new Plot();
	}
	
	public Property(String name, String city, double rentAmount, String owner, int x, int y, int width, int depth)
	{
		this.propertyName = name;
		this.city = city;
		this.owner = owner;
		this.rentAmount = rentAmount;
		this.plot = new Plot(x, y, width, depth);
	}
	
	// sets city
	public void setCity(String city) 
	{
		this.city = city;
	}
	
	// returns city
	public String getCity()
	{
		return city;
	}
	
	// sets propertyName
	public void setPropertyName(String propertyName)
	{
		this.propertyName = propertyName;
	}
	
	// returns propertyName
	public String getPropertyName()
	{
		return propertyName;
	}
	
	// sets owner
	public void setOwner(String owner) 
	{
		this.owner = owner;
	}
	
	// returns owner
	public String getOwner()
	{
		return owner;
	}
		
	// sets rentAmount
	public void setRentAmount(double rentAmount) 
	{
		this.rentAmount = rentAmount;
	}
	
	// gets rentAmount
	public double getRentAmount() 
	{
		return rentAmount;
	}
	
	
	// returns the plot instance
	public Plot getPlot() 
	{
		return plot;
	}
	
	
	// sets the Plot values and returns the Plot instance
	public Plot setPlot(int x, int y, int width, int height)
	{
		plot = new Plot(x, y, width, height);
		return plot;
	}
	
	// prints out the name, city, owner, and rentAmount for a property
	public String toString()
	{
		System.out.println("Ethan Tran");
		return String.format("Property Name: %s\nLocated in %s\nBelonging to: %s\n Rent Amount: %s", propertyName, city, owner, rentAmount);
	}
}

//Ethan Tran