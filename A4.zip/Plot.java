package Assignment4;

public class Plot
{
	private int x;
	private int y;
	private int width;
	private int depth;
	
	public Plot() 
	{
		x = 0;
		y = 0;
		width = 1;
		depth = 1;
	}
	
	public Plot(Plot p) 
	{
		x = p.x;
		y = p.y;
		width = p.width;
		depth = p.depth;
	}
	
	public Plot(int x, int y, int width, int depth)
	{
		this.x = x;
		this.y = y;
		this.width = width;
		this.depth = depth;
	}
	
	// sets x value
	public void setX(int x) 
	{
		this.x = x;
	}
	
	// returns x value
	public int getX() 
	{
		return x;
	}
	
	// sets y value
	public void setY(int y)
	{
		this.y = y;
	}
	
	// returns y value
	public int getY() 
	{
		return y;
	}
	
	// sets the width
	public void setWidth(int width) 
	{
		this.width = width;
	}
	
	// gets width
	public int getWidth() 
	{
		return width;
	}
	
	// sets depth
	public void setDepth(int depth)
	{
		this.depth = depth;
	}
	
	// gets depth
	public int getDepth() 
	{
		return depth;
	}
	
	//determines if the plot overlaps the parameter,returns true if the two plots overlap, otherwise false
	public boolean overlaps(Plot plot) 
	{
		Plot biggest;
		Plot smallest;
		
		if (this.x == plot.x && this.y == plot.y) 
		{
			return true;
		}
		
		if (this.width > plot.width) 
		{
			biggest = this;
			smallest = plot;
		} 
		else 
		{
			biggest = plot;
			smallest = this;	
		}
		
		int plot1x1 = biggest.x;
		int plot1x2 = biggest.x + biggest.width;
		int plot2x1 = smallest.x;
		int plot2x2 = smallest.x + smallest.width;
		
		
		if (!((plot2x1 > plot1x1 && plot2x1 < plot1x2) || (plot2x2 > plot1x1 && plot2x2 < plot1x2))) 
		{
			return false;
		}
		
		if (this.depth > plot.depth) 
		{
			biggest = this;
			smallest = plot;
		} 
		else 
		{
			biggest = plot;
			smallest = this;	
		}	
		int plot1y1 = biggest.y;
		int plot1y2 = biggest.y + biggest.depth;
		int plot2y1 = smallest.y;
		int plot2y2 = smallest.y + smallest.depth;
		
		if (!((plot2y1 > plot1y1 && plot2y1 < plot1y2) || (plot2y2 > plot1y1 && plot2y2 < plot1y2)))
		{
			return false;
		}		
		return true;
	}
	
	//takes a Plot instance and determines if the current plot contains it.
	public boolean encompasses(Plot plot) 
	{		
		if (this.width < plot.width || this.depth < plot.depth) 
		{
			return false;
		}
		
		int plot1x1 = this.x;
		int plot1x2 = this.x + plot.width;
		int plot2x1 = plot.x;
		int plot2x2 = plot.x + plot.width;
		
		if (!(plot2x1 >= plot1x1 && plot2x1 <= plot1x2) && (plot2x2 >= plot1x1 && plot2x2 <= plot1x2)) 
		{
			return false;
		}
		
		int plot1y1 = this.y;
		int plot1y2 = this.y + plot.depth;
		int plot2y1 = plot.y;
		int plot2y2 = plot.y + plot.depth;
		
		if (!(plot2y1 >= plot1y1 && plot2y1 <= plot1y2) && (plot2y2 >= plot1y1 && plot2y2 <= plot1y2))
		{
			return false;
		}
		
		return true;
	}
	
	// prints X,Y of the upper left corner, width, and depth
	public String toString() 
	{
		return String.format("Upper left: (%d,%d); Width: %d Depth: %d", x, y, width, depth);
	}
}
// Ethan Tran