package Assignment4;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class ManagementCompanyTestSTUDENT 
{
	ManagementCompany co;
	
	@Before
	public void setUp() throws Exception 
	{			
		co = new ManagementCompany("Lechuga and Co", "California", 0.5);
		co.addProperty(new Property ("Random House", "Lockwood", 1, "Flint Lockwood",5,2,1,1));
		co.addProperty("Random Shed", "CloudLane", 1, "Earl Devereaux",1,2,2,2);
		co.addProperty("Random Backyard", "MeatballDrive", 1, "Sam Sparks",9,9,1,1);	
	}

	@After
	public void tearDown() 
	{
		co = null;
	}

	@Test
	public void testAddPropertyDefaultPlot() 
	{
		co.addProperty(new Property("BLAS", "Washington", 1, "John Corot"));
		co.addProperty("BLOP", "Washington", 1, "Carol Corot",7,7,1,1);
		assertEquals(co.addProperty(new Property ("RainbowRoad", "Boucher", 2613, "Carl Roundkick", 2,5,2,2)), -1);
	}
 
	@Test
	public void testMaxRentProp() 
	{
		assertEquals(co.maxRentProp(), 1.0, 0);
	}

	@Test
	public void testTotalRent() 
	{
		assertEquals(co.totalRent(), 3.0, 0);
	}

 }